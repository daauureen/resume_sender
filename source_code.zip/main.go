package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"net/smtp"
	"os"
	"time"

	"github.com/jordan-wright/email"
)

type Report struct {
	CVURL     string `json:"cv_url"`
	Hash      string `json:"hash"`
	UserID    string `json:"user_id"`
	Email     string `json:"email"`
	Timestamp string `json:"timestamp"`
}

func main() {
	cvURL := flag.String("cv-url", "", "CV URL")
	emailAddr := flag.String("email", "", "Your email")
	smtpLogin := flag.String("smtp-login", "", "SMTP login")
	smtpPassword := flag.String("smtp-password", "", "SMTP app password")
	smtpServer := flag.String("smtp-server", "smtp.gmail.com", "SMTP server")
	smtpPort := flag.String("smtp-port", "587", "SMTP port")

	flag.Parse()

	if *cvURL == "" || *emailAddr == "" || *smtpLogin == "" || *smtpPassword == "" {
		fmt.Println("⛔ Все обязательные флаги должны быть указаны")
		flag.Usage()
		os.Exit(1)
	}

	// SHA256 хеш
	hashBytes := sha256.Sum256([]byte(*cvURL))
	hash := hex.EncodeToString(hashBytes[:])

	// user_id = первые 8 символов + 4 случайных
	rand.Seed(time.Now().UnixNano())
	letters := []rune("abcdefghijklmnopqrstuvwxyz0123456789")
	randomPart := make([]rune, 4)
	for i := range randomPart {
		randomPart[i] = letters[rand.Intn(len(letters))]
	}
	userID := fmt.Sprintf("%s-%s", hash[:8], string(randomPart))

	// JSON отчёт
	report := Report{
		CVURL:     *cvURL,
		Hash:      hash,
		UserID:    userID,
		Email:     *emailAddr,
		Timestamp: time.Now().UTC().Format(time.RFC3339),
	}

	jsonFileName := fmt.Sprintf("report_%s.json", userID)
	file, err := os.Create(jsonFileName)
	if err != nil {
		log.Fatal("❌ Ошибка при создании JSON файла:", err)
	}
	defer file.Close()

	err = json.NewEncoder(file).Encode(report)
	if err != nil {
		log.Fatal("❌ Ошибка при записи JSON:", err)
	}

	fmt.Println("✅ JSON отчёт создан:", jsonFileName)

	// Отправка email
	e := email.NewEmail()
	e.From = *emailAddr
	e.To = []string{"szhaisan@wtotem.com"}
	e.Subject = "Golang Test – " + userID
	e.Text = []byte("Автоматическая отправка отчёта")

	_, err = e.AttachFile(jsonFileName)
	if err != nil {
		log.Fatal("❌ Не удалось прикрепить JSON файл:", err)
	}

	_, err = e.AttachFile("source_code.zip")
	if err != nil {
		log.Fatal("❌ Не удалось прикрепить ZIP файл:", err)
	}

	err = e.Send(*smtpServer+":"+*smtpPort, smtp.PlainAuth("", *smtpLogin, *smtpPassword, *smtpServer))
	if err != nil {
		log.Fatal("❌ Ошибка при отправке письма:", err)
	}

	fmt.Println("📨 Письмо успешно отправлено!")
}
